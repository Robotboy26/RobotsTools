import unittest
from unittest.mock import patch, mock_open
from threading import Lock
import os

from src.RobotsTools import *

# //////////////////////////////////////////////////////////////////////////////////////////

class TestLogFile(unittest.TestCase):
    def setUp(self):
        self.filename = "log.txt"
        with open(self.filename, 'w') as file:
            file.write("test")

    def tearDown(self):
        os.remove(self.filename)

    def testFileCreated(self):
        self.assertEqual(LogFile(self.filename), "File created")
        self.assertTrue(os.path.exists(self.filename))

    def testFileExistsNotTruncated(self):
        self.assertEqual(LogFile(self.filename, ClearLogFile=False), "File exists not truncated")
        with open(self.filename, 'r') as file:
            self.assertEqual(file.read(), "test")

    def testFileExistsTruncated(self):
        self.assertEqual(LogFile(self.filename, ClearLogFile=True), "File exists truncated")
        with open(self.filename, 'r') as file:
            self.assertEqual(file.read(), "")

    def testGlobalDefaultLogFile(self):
        LogFile(self.filename)
        self.assertEqual(defaultLogFile, self.filename)

# //////////////////////////////////////////////////////////////////////////////////////////

#class TestLog(unittest.TestCase):
#    def setUp(self):
#        self.defaultLogFile = "testLogFile.txt"
#        self.defaultLogMessageType = "INFO"
#        self.lock = Lock()
#        self.logSettings = True
#
#    def tearDown(self):
#        os.remove(self.defaultLogFile)
#
#    @patch('Log.Debug')
#    def testLogSucceeded(self, mock_debug):
#        mock_debug.return_value = None
#        m = mock_open()
#        with patch('builtins.open', m):
#            result = Log.Log("Test message", self.defaultLogMessageType, self.defaultLogFile, self.logSettings, self.lock)
#        self.assertEqual(result, "Log succeeded")
#        m.assert_called_once_with(self.defaultLogFile, 'a')
#        handle = m()
#        handle.write.assert_called_once_with("Test message\n")
#
#    @patch('Log.Debug')
#    def testLogFailed(self, mock_debug):
#        mock_debug.return_value = None
#        m = mock_open()
#        with patch('builtins.open', m):
#            result = Log.Log("Test message", self.defaultLogMessageType, self.defaultLogFile, False, self.lock)
#        self.assertEqual(result, "LogSettings is False")
#        mock_debug.assert_not_called()
#        handle = m()
#        handle.write.assert_not_called()

if __name__ == '__main__':
    unittest.main()

